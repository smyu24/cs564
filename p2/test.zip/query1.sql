-- 1. Find the number of users in the database.
SELECT COUNT(userID)
FROM Users;